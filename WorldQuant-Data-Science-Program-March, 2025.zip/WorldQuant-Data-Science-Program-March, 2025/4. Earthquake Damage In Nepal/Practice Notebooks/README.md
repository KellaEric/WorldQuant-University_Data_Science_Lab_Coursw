# 040-Earthquake-Damage-in-Nepal

- sqlite
- logistic-regression
- decision-tree
- demographics
    - Ethical Data Science
