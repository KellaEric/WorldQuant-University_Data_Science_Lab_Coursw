%load_ext sql
%sql sqlite:////home/jovyan/<fileName e.g nepal>.sqlite

# sample output
'Connected: @/home/jovyan/nepal.sqlite'
