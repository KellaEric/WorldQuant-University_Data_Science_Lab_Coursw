import libraries

ConfusionMatrixDisplay.from_estimator(model, X_test, y_test);
