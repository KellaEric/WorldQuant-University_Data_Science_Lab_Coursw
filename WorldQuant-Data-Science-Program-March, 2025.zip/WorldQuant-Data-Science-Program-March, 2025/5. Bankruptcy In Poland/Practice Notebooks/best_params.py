import libraries

# Method 1
best_params = model.best_params_
print(best_params)

# Method 2
model.predict(X_train_over)
