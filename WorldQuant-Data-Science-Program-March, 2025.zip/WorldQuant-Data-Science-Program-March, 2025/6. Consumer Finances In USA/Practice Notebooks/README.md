# 060-consumer-finance-in-usa
## Unsupervised learning, specifically clustering

- Side-by-side bar chart
- K-means clustering model
- Clustering-2-features vs -multiple-features
- Feature selection based on variance
- Principal component analysis (PCA)
