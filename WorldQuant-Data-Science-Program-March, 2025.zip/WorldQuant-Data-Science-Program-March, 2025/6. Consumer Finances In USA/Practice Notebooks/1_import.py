df = pd.read_csv("<filePath>")
print("df shape:", df.shape)
df.head()
