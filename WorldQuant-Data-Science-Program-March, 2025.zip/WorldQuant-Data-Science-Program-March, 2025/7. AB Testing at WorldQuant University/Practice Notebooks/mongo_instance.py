""" """

import imports
from our_mongo_class import MongoRepository


# An instance of class MongoRepository
repo = MongoRepository()
