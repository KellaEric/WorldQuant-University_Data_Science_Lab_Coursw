y_test_pred = pd.Series(model.predict(X_test))
y_test_pred.head()

# sample output
0    53538.366480
1    53171.988369
2    34263.884179
3    53488.425607
4    68738.924884
dtype: float64
