# concatenate 2 data frames using concat

df = pd.concat([df1, df2])
