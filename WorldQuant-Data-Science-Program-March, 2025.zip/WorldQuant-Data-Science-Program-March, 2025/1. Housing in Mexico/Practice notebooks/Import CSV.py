import matplotlib.pyplot as plt
import pandas as pd
import plotly.express as px

df1 = pd.read_csv("data/brasil-real-estate-1.csv")
df1.shape

#Output
(12834, 6)
