# counts the number of items/ things

homes_by_state = df_south["state"].value_counts()
homes_by_state


Rio Grande do Sul    2643
Santa Catarina       2634
Paraná               2544
Name: state, dtype: int64
