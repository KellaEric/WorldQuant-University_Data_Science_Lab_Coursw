# work-ds-curriculum-010-housing-in-mexico

WQU DATA SCIENCE LAB PROJECT 1
HOUSING IN MEXICO

Key concepts learnt and their application
